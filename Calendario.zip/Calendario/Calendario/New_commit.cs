﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Calendario
{
    public partial class New_commit : Form
    {
        public New_commit()
        {
            InitializeComponent();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                label5.BackColor = colorDialog1.Color;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string ciao2 = textBox1.Text.Trim();
            if (ciao2 == "")
            {
                MessageBox.Show("Inserire un titolo valido");
            }
            else
            {
                if(ora_inizio.Value > 24 && minuto_inizio.Value > 60 && ora_durata.Value > 24 && minuti_durata.Value > 60)
                {
                    MessageBox.Show("Inserire un orario valido");
                }
                else
                {
                    if (textBox1.Text.Trim() == "" && textBox2.Text.Trim() == "")
                    {
                        MessageBox.Show("Inserire una descrizione valida");
                    }
                    else
                    {
                        string titolo = textBox1.Text;
                        string descrizione = textBox2.Text;
                        DateTime data = dateTimePicker1.Value;
                        Color colore = label5.BackColor;
                        decimal Hour_start = ora_inizio.Value;
                        decimal Minute_start = minuto_inizio.Value;
                        decimal Hour_duration = ora_durata.Value;
                        decimal Minute_duration = minuti_durata.Value;
                        string contenuto = $"{titolo}§{descrizione}§{data:yyyy-MM-dd}§{Hour_start}§{Minute_start}§{Hour_duration}§{Minute_duration}§{colore.ToArgb()}";
                        string percorso = Path.Combine(Application.StartupPath, "calendario.txt");
                        File.WriteAllText(percorso, contenuto);
                    }
                }
            }
        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click_1(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Ora_inizio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Minuto_inizio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Ora_durata_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Minuti_durata_ValueChanged(object sender, EventArgs e)
        {

        }
        #region menu
        private void TitoloToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void GestisciEventiToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void HomepageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void NuovoEventoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            New_commit new_Commit = new New_commit();
            new_Commit.ShowDialog();
        }
        #endregion

    }
}
