﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Calendario
{
    public partial class luca : Form
    {
        public luca(string titolo, string descrizione, DateTime data, Color colore)
        {
            InitializeComponent();

            // Imposta i valori sulle etichette
            labelTitolo.Text = titolo;
            labelDescrizione.Text = descrizione;
            labelData.Text = data.ToString("dd/MM/yyyy HH:mm");
            panelColore.BackColor = colore;
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            // Eventuale logica di disegno personalizzata
        }
    }
}
