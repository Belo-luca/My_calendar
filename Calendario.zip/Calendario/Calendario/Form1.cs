﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

/*
 *SISTEMARE L'UPLOAD DEL PROGETTO 
 */


namespace Calendario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void MonthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
  
        }

        private void Show_today_Click(object sender, EventArgs e)
        {

        }

        private void New_commit_Click(object sender, EventArgs e)
        {
            New_commit form_aggiungi_evento = new New_commit();
            form_aggiungi_evento.Show();
        }

        private void Del_commit_Click(object sender, EventArgs e)
        {

        }

        private void Edit_commit_Click(object sender, EventArgs e)
        {

        }

        private void Help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("In questa pagina puoi vedere i tuoi impegni selezionando la data dal calendario, premere visualizza e poi a destra vedrai i tuoi impegni. Mentre per modificare, eliminare o creare nuovi eventi: guarda il menù", "Yuhao è cinese", MessageBoxButtons.OK);
        }

        private void Show_label_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void AggiungiEventoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        #region menu
        private void Neweventmenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            New_commit new_Commit = new New_commit();
            new_Commit.Show();
        }

        #endregion

        private void Homepagemenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 home_Page = new Form1();
            home_Page.Show();
        }

        private void Label2_Click(object sender, EventArgs e)
        {
            
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            New_commit new_Commit = new New_commit();
            new_Commit.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_monthly view_Monthly = new View_monthly();
            view_Monthly.Show();
        }

        private void Button4_Click(object sender, EventArgs e)
        {

        }

        private void Button6_Click(object sender, EventArgs e)
        {

        }

        private void VisualizzaElencoProgettiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_monthly view_Monthly = new View_monthly();
            view_Monthly.Show();
        }

        private void Deleteeventmenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete delete_Commit = new Delete();
            delete_Commit.Show();
        }
    }
}
