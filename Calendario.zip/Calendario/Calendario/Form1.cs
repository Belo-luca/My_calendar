﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calendario
{
    public partial class Form1 : Form
    {
        //inizializza il form
        public Form1()
        {
            InitializeComponent();
        }
        //gestisce il click sul menu aggiungi evento
        private void AggiungiEventoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        #region menu
        //entra nel form nuovo evento
        private void Neweventmenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            New_commit new_Commit = new New_commit();
            new_Commit.Show();
        }
        //entra nel form nuovo evento
        private void Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            New_commit new_Commit = new New_commit();
            new_Commit.Show();
        }
        //entra nel form visualizza elenco progetti
        private void Button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_monthly view_Monthly = new View_monthly();
            view_Monthly.Show();
        }
        //entra nel form elimina evento
        private void Button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete delete_Commit = new Delete();
            delete_Commit.Show();
        }
        //entra nel form visualizza elenco progetti
        private void VisualizzaElencoProgettiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_monthly view_Monthly = new View_monthly();
            view_Monthly.Show();
        }
        //entra nel form elimina evento
        private void Deleteeventmenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete delete_Commit = new Delete();
            delete_Commit.Show();
        }

        //torna alla home page
        private void Homepagemenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 home_Page = new Form1();
            home_Page.Show();
        }
        #endregion
    }
}
