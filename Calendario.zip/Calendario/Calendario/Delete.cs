﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Calendario
{
    public partial class Delete : Form
    {

        //inizializza gli eventi da file e del designer
        public Delete()
        {
            InitializeComponent();
            Upload_events();
        }

        //struct degli impegni
        public struct Impegno
        {
            public string titolo;
            public string descrizione;
            public DateTime inizio;
            public TimeSpan durata;
            public Color colore;
        }

        //crea un vettore con gli impegni
        private Impegno[] Impegni;


        //funzione per permettere di fare l'upload degli eventi
        private void Upload_events()
        {
            string percorso = Path.Combine(Application.StartupPath, "calendario.txt");

            if (!File.Exists(percorso))
            {
                Impegni = new Impegno[0];
                return;
            }

            string[] righe = File.ReadAllLines(percorso);
            Impegni = new Impegno[righe.Length];

            for (int i = 0; i < righe.Length; i++)
            {
                string[] parti = righe[i].Split('§');
                Impegni[i].titolo = parti[0];
                Impegni[i].descrizione = parti[1];
                DateTime giorno = DateTime.Parse(parti[2]);
                int oraInizio = int.Parse(parti[3]);
                int minutoInizio = int.Parse(parti[4]);
                int durataOre = int.Parse(parti[5]);
                int durataMinuti = int.Parse(parti[6]);
                Impegni[i].colore = Color.FromArgb(int.Parse(parti[7]));
                Impegni[i].inizio = new DateTime(giorno.Year, giorno.Month, giorno.Day, oraInizio, minutoInizio, 0);
                Impegni[i].durata = new TimeSpan(durataOre, durataMinuti, 0);
            }
        }

        //con questo metodo trova l'impegno
        private void Found_event()
        {
            string Titolo = textBox1.Text;
            string Descrizione = textBox2.Text;
            DateTime Giorno = dateTimePicker1.Value;
            int OraInizio = (int)ora_inizio.Value;
            int MinutoInizio = (int)minuto_inizio.Value;
            int DurataOre = (int)ora_durata.Value;
            int DurataMinuti = (int)minuti_durata.Value;

            int j = -1;
            for (int i = 0; i < Impegni.Length; i++)
            {
                if (Impegni[i].titolo == Titolo &&
                    Impegni[i].descrizione == Descrizione &&
                    Impegni[i].inizio.Date == Giorno.Date &&
                    Impegni[i].inizio.Hour == OraInizio &&
                    Impegni[i].inizio.Minute == MinutoInizio &&
                    Impegni[i].durata.Hours == DurataOre &&
                    Impegni[i].durata.Minutes == DurataMinuti)
                {
                    j = i;
                    break;
                }
            }
            //se non trova l'evento avverte l'utente
            if (j == -1)
            {
                MessageBox.Show("Evento non trovato!");
                return;
            }

            MessageBox.Show("Evento trovato e cancellato!");

            // Nuovo array con il numero di impegni minore
            string[] righeNuove = new string[Impegni.Length - 1];
            int k = 0;

            // Copia tutti gli impegni tranne quello da eliminare
            for (int i = 0; i < Impegni.Length; i++)
            {
                if (i == j) continue;

                Impegno imp = Impegni[i];
                righeNuove[k] = $"{imp.titolo}§{imp.descrizione}§{imp.inizio:yyyy-MM-dd}§{imp.inizio.Hour}§{imp.inizio.Minute}§{imp.durata.Hours}§{imp.durata.Minutes}§{imp.colore.ToArgb()}";
                k++;
            }

            string percorso = Path.Combine(Application.StartupPath, "calendario.txt");
            File.WriteAllLines(percorso, righeNuove);

            Upload_events();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Found_event();
        }
        #region genera gli elementi
        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void Label6_Click(object sender, EventArgs e)
        {

        }
        private void Label5_Click_1(object sender, EventArgs e)
        {

        }

        private void Ora_inizio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Minuto_inizio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Ora_durata_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Minuti_durata_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Delete_Load(object sender, EventArgs e)
        {

        }
        #endregion

        #region menu
        private void homepageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 home = new Form1();
            home.ShowDialog();
        }

        private void nuovoEventoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            New_commit nuovo = new New_commit();
            nuovo.ShowDialog();
        }

        private void eliminaImpegnoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete elimina = new Delete();
            elimina.ShowDialog();
        }

        private void visualizzaElencoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_monthly visualizza = new View_monthly();
            visualizza.ShowDialog();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }
        #endregion
    }
}
