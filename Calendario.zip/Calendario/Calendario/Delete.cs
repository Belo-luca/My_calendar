﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calendario
{
    public partial class Delete : Form
    {
        public Delete()
        {
            InitializeComponent();
            Upload_events();
        }

        public struct Impegno
        {
            public string titolo;
            public string descrizione;
            public DateTime inizio;   // data e ora di inizio
            public TimeSpan durata;   // durata completa (ore + minuti)
            public Color colore;
        }

        private Impegno[] Impegni;

        private void Upload_events()
        {
            string percorso = Path.Combine(Application.StartupPath, "calendario.txt");
            string[] righe = File.ReadAllLines(percorso);
            Impegni = new Impegno[righe.Length];
            for (int i = 0; i < righe.Length; i++)
            {
                string[] parti = righe[i].Split('§');
                Impegni[i].titolo = parti[0];
                Impegni[i].descrizione = parti[1];
                DateTime giorno = DateTime.Parse(parti[2]);
                int oraInizio = int.Parse(parti[3]);
                int minutoInizio = int.Parse(parti[4]);
                int durataOre = int.Parse(parti[5]);
                int durataMinuti = int.Parse(parti[6]);
                Impegni[i].colore = Color.FromArgb(int.Parse(parti[7]));
                Impegni[i].inizio = new DateTime(giorno.Year, giorno.Month, giorno.Day,oraInizio, minutoInizio, 0);
                Impegni[i].durata = new TimeSpan(durataOre, durataMinuti, 0);
            }
        }

        private void Delete_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Ora_inizio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Minuto_inizio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Ora_durata_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Minuti_durata_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {

        }
        private void Found_event()
        {
            string Titolo = textBox1.Text;
            string Descrizione = textBox2.Text;
            DateTime Giorno = dateTimePicker1.Value;
            int OraInizio = (int)ora_inizio.Value;
            int MinutoInizio = (int)minuto_inizio.Value;
            int DurataOre = (int)ora_durata.Value;
            int DurataMinuti = (int)minuti_durata.Value;
            int j = 0;
            for (j = 0; j < Impegni.Length; j++)
            {
                if (Impegni[j].titolo == Titolo &&
                    Impegni[j].descrizione == Descrizione &&
                    Impegni[j].inizio.Year == Giorno.Year &&
                    Impegni[j].inizio.Month == Giorno.Month &&
                    Impegni[j].inizio.Day == Giorno.Day &&
                    Impegni[j].inizio.Hour == OraInizio &&
                    Impegni[j].inizio.Minute == MinutoInizio &&
                    Impegni[j].durata.Hours == DurataOre &&
                    Impegni[j].durata.Minutes == DurataMinuti)
                {
                    MessageBox.Show("Evento trovato!");
                    return;
                }
                else
                {
                    MessageBox.Show("Evento non trovato!");
                }
            }
            
            for (int i = 0;i < Impegni.Length - 1; i++)
            {
                if (i != j)
                {
                    string titolo = Impegni[i].titolo;
                    string descrizione = Impegni[i].descrizione;
                    DateTime data = Impegni[i].;
                    Color colore = label5.BackColor;
                    decimal Hour_start = ora_inizio.Value;
                    decimal Minute_start = minuto_inizio.Value;
                    decimal Hour_duration = ora_durata.Value;
                    decimal Minute_duration = minuti_durata.Value;
                    string contenuto = $"{titolo}§{descrizione}§{data:yyyy-MM-dd}§{Hour_start}§{Minute_start}§{Hour_duration}§{Minute_duration}§{colore.ToArgb()}";
                    string percorso = Path.Combine(Application.StartupPath, "calendario.txt");
                    File.WriteAllText(percorso, contenuto);
                }
            }
        }
    }
}
