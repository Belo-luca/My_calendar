﻿namespace Calendario
{
    partial class Delete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ora_inizio = new System.Windows.Forms.NumericUpDown();
            this.minuto_inizio = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.ora_durata = new System.Windows.Forms.NumericUpDown();
            this.minuti_durata = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.homepageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestisciEventiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuovoEventoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificaImpegnoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.titoloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificaTitoloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cambiaDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cambiaOraDiInizioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cambiaLaDurataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cambiaIlColoreDiSfondoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminaImpegnoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ora_inizio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minuto_inizio)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ora_durata)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minuti_durata)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.Controls.Add(this.monthCalendar1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker1, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(21, 39);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(767, 366);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(469, 9);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "seleziona data";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(233, 220);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(166, 22);
            this.dateTimePicker1.TabIndex = 7;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.DateTimePicker1_ValueChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(233, 183);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(166, 22);
            this.textBox2.TabIndex = 4;
            this.textBox2.TextChanged += new System.EventHandler(this.TextBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(233, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(166, 22);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Inserisci una descrizione";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Seleziona ora di inizio";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.ora_inizio, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.minuto_inizio, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label5, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(233, 257);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 31);
            this.tableLayoutPanel2.TabIndex = 14;
            // 
            // ora_inizio
            // 
            this.ora_inizio.Location = new System.Drawing.Point(3, 3);
            this.ora_inizio.Name = "ora_inizio";
            this.ora_inizio.Size = new System.Drawing.Size(58, 22);
            this.ora_inizio.TabIndex = 13;
            this.ora_inizio.ValueChanged += new System.EventHandler(this.Ora_inizio_ValueChanged);
            // 
            // minuto_inizio
            // 
            this.minuto_inizio.Location = new System.Drawing.Point(135, 3);
            this.minuto_inizio.Name = "minuto_inizio";
            this.minuto_inizio.Size = new System.Drawing.Size(62, 22);
            this.minuto_inizio.TabIndex = 12;
            this.minuto_inizio.ValueChanged += new System.EventHandler(this.Minuto_inizio_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(69, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 29);
            this.label5.TabIndex = 14;
            this.label5.Text = ":";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 291);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "Seleziona durata";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Controls.Add(this.ora_durata, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.minuti_durata, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label8, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(233, 294);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(200, 31);
            this.tableLayoutPanel3.TabIndex = 16;
            // 
            // ora_durata
            // 
            this.ora_durata.Location = new System.Drawing.Point(3, 3);
            this.ora_durata.Name = "ora_durata";
            this.ora_durata.Size = new System.Drawing.Size(58, 22);
            this.ora_durata.TabIndex = 13;
            this.ora_durata.ValueChanged += new System.EventHandler(this.Ora_durata_ValueChanged);
            // 
            // minuti_durata
            // 
            this.minuti_durata.Location = new System.Drawing.Point(135, 3);
            this.minuti_durata.Name = "minuti_durata";
            this.minuti_durata.Size = new System.Drawing.Size(62, 22);
            this.minuti_durata.TabIndex = 12;
            this.minuti_durata.ValueChanged += new System.EventHandler(this.Minuti_durata_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(69, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 29);
            this.label8.TabIndex = 14;
            this.label8.Text = ":";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Inserisci il nome dell\'evento";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(347, 411);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 36);
            this.button1.TabIndex = 6;
            this.button1.Text = "Elimina";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homepageToolStripMenuItem,
            this.gestisciEventiToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // homepageToolStripMenuItem
            // 
            this.homepageToolStripMenuItem.Name = "homepageToolStripMenuItem";
            this.homepageToolStripMenuItem.Size = new System.Drawing.Size(98, 24);
            this.homepageToolStripMenuItem.Text = "Homepage";
            // 
            // gestisciEventiToolStripMenuItem
            // 
            this.gestisciEventiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuovoEventoToolStripMenuItem,
            this.modificaImpegnoToolStripMenuItem,
            this.eliminaImpegnoToolStripMenuItem});
            this.gestisciEventiToolStripMenuItem.Name = "gestisciEventiToolStripMenuItem";
            this.gestisciEventiToolStripMenuItem.Size = new System.Drawing.Size(117, 24);
            this.gestisciEventiToolStripMenuItem.Text = "Gestisci eventi";
            // 
            // nuovoEventoToolStripMenuItem
            // 
            this.nuovoEventoToolStripMenuItem.Name = "nuovoEventoToolStripMenuItem";
            this.nuovoEventoToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.nuovoEventoToolStripMenuItem.Text = "Nuovo evento";
            // 
            // modificaImpegnoToolStripMenuItem
            // 
            this.modificaImpegnoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.titoloToolStripMenuItem,
            this.modificaTitoloToolStripMenuItem,
            this.cambiaDataToolStripMenuItem,
            this.cambiaOraDiInizioToolStripMenuItem,
            this.cambiaLaDurataToolStripMenuItem,
            this.cambiaIlColoreDiSfondoToolStripMenuItem});
            this.modificaImpegnoToolStripMenuItem.Name = "modificaImpegnoToolStripMenuItem";
            this.modificaImpegnoToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.modificaImpegnoToolStripMenuItem.Text = "Modifica impegno";
            // 
            // titoloToolStripMenuItem
            // 
            this.titoloToolStripMenuItem.Name = "titoloToolStripMenuItem";
            this.titoloToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.titoloToolStripMenuItem.Text = "cambia titolo";
            // 
            // modificaTitoloToolStripMenuItem
            // 
            this.modificaTitoloToolStripMenuItem.Name = "modificaTitoloToolStripMenuItem";
            this.modificaTitoloToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.modificaTitoloToolStripMenuItem.Text = "cambia descrizione";
            // 
            // cambiaDataToolStripMenuItem
            // 
            this.cambiaDataToolStripMenuItem.Name = "cambiaDataToolStripMenuItem";
            this.cambiaDataToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.cambiaDataToolStripMenuItem.Text = "cambia data";
            // 
            // cambiaOraDiInizioToolStripMenuItem
            // 
            this.cambiaOraDiInizioToolStripMenuItem.Name = "cambiaOraDiInizioToolStripMenuItem";
            this.cambiaOraDiInizioToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.cambiaOraDiInizioToolStripMenuItem.Text = "cambia ora di inizio";
            // 
            // cambiaLaDurataToolStripMenuItem
            // 
            this.cambiaLaDurataToolStripMenuItem.Name = "cambiaLaDurataToolStripMenuItem";
            this.cambiaLaDurataToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.cambiaLaDurataToolStripMenuItem.Text = "cambia la durata";
            // 
            // cambiaIlColoreDiSfondoToolStripMenuItem
            // 
            this.cambiaIlColoreDiSfondoToolStripMenuItem.Name = "cambiaIlColoreDiSfondoToolStripMenuItem";
            this.cambiaIlColoreDiSfondoToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.cambiaIlColoreDiSfondoToolStripMenuItem.Text = "cambia il colore di sfondo";
            // 
            // eliminaImpegnoToolStripMenuItem
            // 
            this.eliminaImpegnoToolStripMenuItem.Name = "eliminaImpegnoToolStripMenuItem";
            this.eliminaImpegnoToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.eliminaImpegnoToolStripMenuItem.Text = "elimina impegno";
            // 
            // Delete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.button1);
            this.Name = "Delete";
            this.Text = "Delete";
            this.Load += new System.EventHandler(this.Delete_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ora_inizio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minuto_inizio)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ora_durata)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minuti_durata)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.NumericUpDown ora_inizio;
        private System.Windows.Forms.NumericUpDown minuto_inizio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.NumericUpDown ora_durata;
        private System.Windows.Forms.NumericUpDown minuti_durata;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem homepageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestisciEventiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nuovoEventoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificaImpegnoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem titoloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificaTitoloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cambiaDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cambiaOraDiInizioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cambiaLaDurataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cambiaIlColoreDiSfondoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminaImpegnoToolStripMenuItem;
    }
}